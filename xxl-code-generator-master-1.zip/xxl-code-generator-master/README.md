代码生成平台(在开源的基础上的升级和定制，只限于个人使用不可商用)  使用文档见：https://blog.csdn.net/zhaokk_git/article/details/81983641
        <br>
        <a href="http://www.xuxueli.com/xxl-code-generator/"><strong>-- Home Page --</strong></a>
      


## Introduction


Xxl-Code-Generator 是一个 "controller/service/dao/mybatis/model" 多层的代码生成平台。只需要提供SQL，将会自动生成全部代码。

## Documentation
可以参考  https://github.com/xuxueli



## Features
- 1、简洁：界面操作，简洁直观，可快速上手；
- 2、轻量级：仅需提供建表SQL，即可自动完成代码生成，简洁高效；
- 3、多层代码生成：自动生成  "controller/service/dao/mybatis/model" 多层代码，参与到开发全流程；
- 4、高效：从SQL到API接口，全部代码均支持自动生成，极大提高生产力和效率； 
- 5、在线预览：代码生成后，支持实时在线预览，直接复制使用；


## Communication

- [社区交流](http://www.xuxueli.com/page/community.html)


